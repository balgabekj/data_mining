import pandas as pd

ds = pd.read_csv("Predict Student Dropout and Academic Success.csv")

print(ds.head())